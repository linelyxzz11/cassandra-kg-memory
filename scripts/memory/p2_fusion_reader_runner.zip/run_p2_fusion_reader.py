#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run frozen P2 fusion rankings through the held-out LoCoMo reader.

Recommended input: three already-generated ranking files, one for each method:
ZScore_Linear, MinMax_Linear, Weighted_RRF_dev.

The script does not tune fusion parameters. It validates frozen retrieval MRR,
runs/resumes an OpenAI-compatible chat endpoint, and writes reader metrics plus
paired query/conversation bootstrap confidence intervals.
"""

from __future__ import annotations

import argparse
import ast
import concurrent.futures as cf
import hashlib
import importlib.util
import json
import os
import random
import re
import threading
import time
from collections import Counter
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import requests


def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_json(p: Path) -> dict[str, Any]:
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def resolve(base: Path, value: str | None) -> Path | None:
    if not value:
        return None
    p = Path(os.path.expandvars(os.path.expanduser(value)))
    return p if p.is_absolute() else (base / p).resolve()


def read_table(p: Path) -> pd.DataFrame:
    s = p.suffix.lower()
    if s == ".csv":
        return pd.read_csv(p)
    if s in {".tsv", ".tab"}:
        return pd.read_csv(p, sep="\t")
    if s in {".jsonl", ".ndjson"}:
        return pd.read_json(p, lines=True)
    if s == ".parquet":
        return pd.read_parquet(p)
    raise ValueError(f"Unsupported file type: {p}")


def parse_ids(v: Any) -> list[str]:
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return []
    if isinstance(v, (list, tuple, set)):
        return [str(x).strip() for x in v if str(x).strip()]
    s = str(v).strip()
    for fn in (json.loads, ast.literal_eval):
        try:
            x = fn(s)
            if isinstance(x, (list, tuple, set)):
                return [str(y).strip() for y in x if str(y).strip()]
        except Exception:
            pass
    sep = "|" if "|" in s else ";" if ";" in s else ","
    return [x.strip().strip("'\"") for x in s.split(sep) if x.strip().strip("'\"")]


def norm(s: Any) -> str:
    s = str(s).lower()
    s = re.sub(r"[^\w\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def fallback_f1(pred: str, gold: str, category=None) -> float:
    p, g = norm(pred).split(), norm(gold).split()
    if not p and not g:
        return 1.0
    if not p or not g:
        return 0.0
    overlap = sum((Counter(p) & Counter(g)).values())
    if overlap == 0:
        return 0.0
    precision, recall = overlap / len(p), overlap / len(g)
    return 2 * precision * recall / (precision + recall)


def fallback_em(pred: str, gold: str, category=None) -> float:
    return float(norm(pred) == norm(gold))


def fallback_abstain(pred: str, category=None) -> bool:
    x = norm(pred)
    return any(k in x for k in [
        "no information available", "not mentioned", "insufficient information",
        "not enough information", "cannot be determined"
    ])


def load_evaluator(path: Path | None, strict: bool):
    if path is None:
        if strict:
            raise RuntimeError("strict_alignment=true requires evaluation.adapter_module")
        return fallback_f1, fallback_em, fallback_abstain, "builtin"
    spec = importlib.util.spec_from_file_location("legacy_eval", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load evaluator: {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    for name in ("score_f1", "score_em", "is_abstain"):
        if not hasattr(mod, name):
            raise RuntimeError(f"Evaluator missing function: {name}")
    return mod.score_f1, mod.score_em, mod.is_abstain, sha256_file(path)


def call_metric(fn, pred: str, gold: str, cat: str) -> float:
    try:
        return float(fn(pred, gold, cat))
    except TypeError:
        return float(fn(pred, gold))


def call_abstain(fn, pred: str, cat: str) -> bool:
    try:
        return bool(fn(pred, cat))
    except TypeError:
        return bool(fn(pred))


def load_aliases(path: Path | None) -> dict[str, str]:
    if path is None:
        return {}
    if path.suffix.lower() == ".json":
        return {str(k): str(v) for k, v in load_json(path).items()}
    df = read_table(path)
    return dict(zip(df["alias"].astype(str), df["canonical_id"].astype(str)))


def canonical(mid: Any, aliases: dict[str, str]) -> str:
    x = str(mid).strip()
    seen = set()
    while x in aliases and x not in seen:
        seen.add(x)
        x = aliases[x]
    return x


def load_ranking(path: Path, cols: dict[str, str], aliases: dict[str, str]) -> dict[str, list[str]]:
    df = read_table(path)
    qid, mid = cols["query_id"], cols["memory_id"]
    rank, score = cols.get("rank"), cols.get("score")
    if qid not in df or mid not in df:
        raise KeyError(f"Missing {qid}/{mid} in {path}")
    work = pd.DataFrame({"qid": df[qid].astype(str), "mid": df[mid].map(lambda x: canonical(x, aliases))})
    if rank and rank in df:
        work["rank"] = pd.to_numeric(df[rank], errors="coerce")
        work["score"] = pd.to_numeric(df[score], errors="coerce") if score and score in df else np.nan
    elif score and score in df:
        work["rank"] = np.nan
        work["score"] = pd.to_numeric(df[score], errors="coerce")
    else:
        raise KeyError(f"Ranking file needs rank or score: {path}")
    out: dict[str, list[str]] = {}
    for q, g in work.groupby("qid", sort=False):
        if g["rank"].notna().any():
            g = g.sort_values(["rank", "mid"], ascending=[True, True], kind="mergesort")
        else:
            g = g.sort_values(["score", "mid"], ascending=[False, True], kind="mergesort")
        out[q] = list(dict.fromkeys(g["mid"].astype(str).tolist()))
    return out


def retrieval_per_query(queries: pd.DataFrame, rankings: dict[str, list[str]], cols: dict[str, str]) -> pd.DataFrame:
    rows = []
    for r in queries.to_dict("records"):
        qid = str(r[cols["query_id"]])
        gold = set(r["_gold_ids"])
        first = None
        for i, mid in enumerate(rankings[qid], 1):
            if mid in gold:
                first = i
                break
        rows.append({
            "query_id": qid,
            "conversation_id": str(r[cols["conversation_id"]]),
            "category": str(r[cols["category"]]),
            "R@1": float(first is not None and first <= 1),
            "R@10": float(first is not None and first <= 10),
            "MRR": 0.0 if first is None else 1.0 / first,
            "Hit@10": float(first is not None and first <= 10),
        })
    return pd.DataFrame(rows)


class Cache:
    def __init__(self, path: Path):
        self.path, self.lock, self.data = path, threading.Lock(), {}
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            for line in path.read_text(encoding="utf-8").splitlines():
                try:
                    x = json.loads(line)
                    self.data[x["cache_key"]] = x
                except Exception:
                    pass

    def get(self, key: str):
        return self.data.get(key)

    def put(self, x: dict[str, Any]):
        with self.lock:
            if x["cache_key"] in self.data:
                return
            with self.path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(x, ensure_ascii=False) + "\n")
            self.data[x["cache_key"]] = x


class Client:
    def __init__(self, cfg: dict[str, Any]):
        self.base = str(cfg.get("base_url") or os.environ.get(cfg.get("base_url_env", "LLM_BASE_URL"), "")).rstrip("/")
        self.key = str(cfg.get("api_key") or os.environ.get(cfg.get("api_key_env", "LLM_API_KEY"), ""))
        self.model = str(cfg.get("model") or os.environ.get(cfg.get("model_env", "LLM_MODEL"), ""))
        self.endpoint = str(cfg.get("endpoint", "/chat/completions"))
        self.temp = float(cfg.get("temperature", 0))
        self.max_tokens = int(cfg.get("max_tokens", 96))
        self.timeout = float(cfg.get("timeout_seconds", 120))
        self.retries = int(cfg.get("max_retries", 6))
        self.system = str(cfg.get("system_prompt", ""))
        self.extra_body = dict(cfg.get("extra_body", {}))
        if not self.base or not self.key or not self.model:
            raise RuntimeError("Missing LLM_BASE_URL / LLM_API_KEY / LLM_MODEL")

    def run(self, prompt: str) -> tuple[str, int]:
        messages = ([{"role": "system", "content": self.system}] if self.system else []) + [{"role": "user", "content": prompt}]
        body = {"model": self.model, "messages": messages, "temperature": self.temp,
                "max_tokens": self.max_tokens, **self.extra_body}
        headers = {"Authorization": f"Bearer {self.key}", "Content-Type": "application/json"}
        err = None
        for attempt in range(self.retries + 1):
            try:
                res = requests.post(self.base + self.endpoint, headers=headers, json=body, timeout=self.timeout)
                if res.status_code >= 400:
                    raise RuntimeError(f"HTTP {res.status_code}: {res.text[:500]}")
                return str(res.json()["choices"][0]["message"]["content"]).strip(), attempt
            except Exception as e:
                err = e
                if attempt == self.retries:
                    break
                time.sleep(min(60, 2 ** attempt + random.random()))
        raise RuntimeError(f"API failed: {err}")


def bootstrap(values: np.ndarray, n: int, seed: int) -> tuple[float, float, float]:
    rng = np.random.default_rng(seed)
    samples = np.empty(n)
    for i in range(n):
        samples[i] = values[rng.integers(0, len(values), len(values))].mean()
    return float(values.mean()), float(np.quantile(samples, .025)), float(np.quantile(samples, .975))


def cluster_bootstrap(df: pd.DataFrame, n: int, seed: int) -> tuple[float, float, float]:
    groups = {k: g["delta"].to_numpy() for k, g in df.groupby("conversation_id")}
    keys = list(groups)
    rng = np.random.default_rng(seed)
    samples = np.empty(n)
    for i in range(n):
        selected = rng.choice(keys, len(keys), replace=True)
        samples[i] = np.concatenate([groups[k] for k in selected]).mean()
    return float(df["delta"].mean()), float(np.quantile(samples, .025)), float(np.quantile(samples, .975))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--validate-only", action="store_true")
    ap.add_argument("--offline", action="store_true")
    args = ap.parse_args()

    cfg_path = Path(args.config).resolve()
    base = cfg_path.parent
    cfg = load_json(cfg_path)
    out = resolve(base, cfg.get("output_dir", "reports/p2_fusion_reader_final"))
    assert out is not None
    out.mkdir(parents=True, exist_ok=True)
    strict = bool(cfg.get("strict_alignment", True))
    cols = cfg["columns"]
    aliases = load_aliases(resolve(base, cfg.get("gold_id_aliases")))

    qpath = resolve(base, cfg["queries"])
    mpath = resolve(base, cfg["memories"])
    prompt_path = resolve(base, cfg["reader"].get("prompt_file"))
    eval_path = resolve(base, cfg["evaluation"].get("adapter_module"))
    assert qpath and mpath
    if strict and (not prompt_path or not eval_path):
        raise RuntimeError("Strict mode requires exact prompt_file and evaluator adapter_module")

    queries = read_table(qpath)
    for c in [cols["query_id"], cols["question"], cols["answer"], cols["category"], cols["conversation_id"], cols["gold_memory_ids"]]:
        if c not in queries:
            raise KeyError(f"Missing query column: {c}")
    queries["_gold_ids"] = queries[cols["gold_memory_ids"]].map(lambda x: [canonical(y, aliases) for y in parse_ids(x)])
    if len(queries) != int(cfg.get("expected_query_count", len(queries))):
        raise RuntimeError(f"Expected {cfg['expected_query_count']} queries, got {len(queries)}")

    mem = read_table(mpath)
    memories = {canonical(mid, aliases): str(text) for mid, text in zip(mem[cols["memory_id"]], mem[cols["memory_text"]])}

    rankings, retrieval_frames, retrieval_summary = {}, [], []
    for method, raw_path in cfg["ranking_files"].items():
        p = resolve(base, raw_path)
        assert p
        ranking = load_ranking(p, cols, aliases)
        missing = set(queries[cols["query_id"]].astype(str)) - set(ranking)
        if missing:
            raise RuntimeError(f"{method}: missing {len(missing)} queries")
        rankings[method] = ranking
        d = retrieval_per_query(queries, ranking, cols)
        d["method"] = method
        retrieval_frames.append(d)
        retrieval_summary.append({"Method": method, **{k: d[k].mean() for k in ["R@1", "R@10", "MRR", "Hit@10"]}})
    retrieval = pd.concat(retrieval_frames, ignore_index=True)
    retrieval.to_csv(out / "retrieval_per_query.csv", index=False)
    retrieval_overall = pd.DataFrame(retrieval_summary)
    retrieval_overall.to_csv(out / "retrieval_overall.csv", index=False)

    gate_rows, gate_ok = [], True
    tol = float(cfg.get("gate_tolerance", 1e-4))
    for method, expected in cfg.get("expected_retrieval", {}).items():
        actual_row = retrieval_overall[retrieval_overall.Method == method]
        if actual_row.empty:
            gate_rows.append({"method": method, "metric": "*", "status": "MISSING"})
            gate_ok = False
            continue
        for metric, exp in expected.items():
            act = float(actual_row.iloc[0][metric])
            ok = abs(act - float(exp)) <= tol
            gate_rows.append({"method": method, "metric": metric, "expected": exp, "actual": act,
                              "delta": act - float(exp), "status": "PASS" if ok else "FAIL"})
            gate_ok &= ok
    pd.DataFrame(gate_rows).to_csv(out / "retrieval_gate.csv", index=False)
    json.dump({"retrieval_gate_pass": gate_ok, "all_pass": gate_ok}, (out / "alignment_checks.json").open("w"), indent=2)
    if not gate_ok:
        raise RuntimeError("Retrieval gate failed; reader was not run")
    if args.validate_only:
        print("Validation PASS")
        print(retrieval_overall.to_string(index=False))
        return 0

    prompt = prompt_path.read_text(encoding="utf-8") if prompt_path else "Memory:\n{context}\n\nQuestion: {question}\nAnswer:"
    prompt_hash = sha256_text(prompt)
    score_f1, score_em, is_abstain, evaluator_hash = load_evaluator(eval_path, strict)
    top_k = int(cfg["reader"].get("top_k_context", 10))
    item_template = cfg["reader"].get("memory_item_template", "[Memory {index} | {memory_id}]\n{text}")
    cache = Cache(out / "reader_cache.jsonl")
    client = None if args.offline else Client(cfg["reader"])
    reader_cfg_hash = sha256_text(json.dumps(cfg["reader"], sort_keys=True, ensure_ascii=False))

    q_by_id = {str(r[cols["query_id"]]): r for r in queries.to_dict("records")}
    tasks = []
    for method, ranking in rankings.items():
        for qid, row in q_by_id.items():
            mids = ranking[qid][:top_k]
            missing = [m for m in mids if m not in memories]
            if missing:
                raise RuntimeError(f"Missing raw memory text for {method}/{qid}: {missing[:3]}")
            context = "\n\n".join(item_template.format(index=i, memory_id=m, text=memories[m]) for i, m in enumerate(mids, 1))
            user_prompt = prompt.format(question=row[cols["question"]], context=context, query_id=qid,
                                        category=row[cols["category"]], conversation_id=row[cols["conversation_id"]])
            key = sha256_text(json.dumps({"method": method, "query_id": qid, "mids": mids,
                                          "question": row[cols["question"]], "prompt": prompt_hash,
                                          "reader": reader_cfg_hash}, sort_keys=True, ensure_ascii=False))
            tasks.append((method, qid, mids, user_prompt, key))

    counts = Counter()
    lock = threading.Lock()
    start = time.time()

    def one(task):
        method, qid, mids, user_prompt, key = task
        old = cache.get(key)
        if old:
            with lock: counts["cache_hits"] += 1
            return old
        if args.offline:
            raise RuntimeError(f"Offline cache miss: {method}/{qid}")
        assert client
        prediction, retries = client.run(user_prompt)
        x = {"cache_key": key, "method": method, "query_id": qid, "ordered_memory_ids": mids,
             "prediction": prediction, "retries": retries}
        cache.put(x)
        with lock:
            counts["api_calls"] += 1
            counts["retries"] += retries
        return x

    results, errors = [], []
    with cf.ThreadPoolExecutor(max_workers=int(cfg["reader"].get("workers", 8))) as ex:
        futs = {ex.submit(one, t): t for t in tasks}
        for i, fut in enumerate(cf.as_completed(futs), 1):
            try:
                results.append(fut.result())
            except Exception as e:
                counts["failures"] += 1
                errors.append({"method": futs[fut][0], "query_id": futs[fut][1], "error": repr(e)})
            if i % 100 == 0 or i == len(tasks):
                print(f"\r{i}/{len(tasks)} API={counts['api_calls']} cache={counts['cache_hits']} fail={counts['failures']}", end="", flush=True)
    print()
    if errors:
        pd.DataFrame(errors).to_csv(out / "api_errors.csv", index=False)
        raise RuntimeError(f"{len(errors)} API calls failed; rerun to resume")

    ret_lookup = retrieval.set_index(["method", "query_id"])
    rows = []
    for x in results:
        row = q_by_id[x["query_id"]]
        pred, gold, cat = x["prediction"], str(row[cols["answer"]]), str(row[cols["category"]])
        r = ret_lookup.loc[(x["method"], x["query_id"])]
        rows.append({
            "method": x["method"], "query_id": x["query_id"],
            "conversation_id": str(row[cols["conversation_id"]]), "category": cat,
            "prediction": pred, "rF1": call_metric(score_f1, pred, gold, cat),
            "rEM": call_metric(score_em, pred, gold, cat),
            "WrongAbst": float(call_abstain(is_abstain, pred, cat)),
            "R@1": r["R@1"], "R@10": r["R@10"], "MRR": r["MRR"], "Hit@10": r["Hit@10"]
        })
    perq = pd.DataFrame(rows)
    perq.to_json(out / "reader_predictions.jsonl", orient="records", lines=True, force_ascii=False)
    overall = perq.groupby("method", as_index=False).agg(n=("query_id", "count"), **{
        "R@1": ("R@1", "mean"), "R@10": ("R@10", "mean"), "MRR": ("MRR", "mean"),
        "Hit@10": ("Hit@10", "mean"), "rF1": ("rF1", "mean"), "rEM": ("rEM", "mean"),
        "WrongAbst": ("WrongAbst", "mean")}).rename(columns={"method": "Method"})
    overall.to_csv(out / "01_reader_overall.csv", index=False)
    perq.groupby(["method", "category"], as_index=False).agg(n=("query_id", "count"), MRR=("MRR", "mean"),
        **{"R@10": ("R@10", "mean"), "rF1": ("rF1", "mean"), "rEM": ("rEM", "mean"),
           "WrongAbst": ("WrongAbst", "mean")}).rename(columns={"method": "Method"}).to_csv(out / "02_reader_by_category.csv", index=False)

    qboot, cboot, perconv, loo, wtl = [], [], [], [], []
    samples, seed = int(cfg.get("bootstrap_samples", 10000)), int(cfg.get("seed", 20260717))
    for pi, (a, b) in enumerate(cfg.get("comparisons", [])):
        aa = perq[perq.method == a].set_index("query_id")
        bb = perq[perq.method == b].set_index("query_id")
        ids = aa.index.intersection(bb.index)
        for metric in ["MRR", "rF1", "rEM", "WrongAbst"]:
            delta = aa.loc[ids, metric].to_numpy(float) - bb.loc[ids, metric].to_numpy(float)
            mean, lo, hi = bootstrap(delta, samples, seed + pi * 100 + len(metric))
            qboot.append({"comparison": f"{a} - {b}", "metric": metric, "mean_delta": mean, "ci_low": lo, "ci_high": hi})
            tmp = aa.loc[ids, ["conversation_id"]].copy(); tmp["delta"] = delta
            mean, lo, hi = cluster_bootstrap(tmp.reset_index(), samples, seed + pi * 1000 + len(metric))
            cboot.append({"comparison": f"{a} - {b}", "metric": metric, "mean_delta": mean, "ci_low": lo, "ci_high": hi})
            for conv, g in tmp.groupby("conversation_id"):
                perconv.append({"comparison": f"{a} - {b}", "metric": metric, "conversation_id": conv,
                                "n": len(g), "mean_delta": g.delta.mean()})
            for conv in sorted(tmp.conversation_id.unique()):
                kept = tmp[tmp.conversation_id != conv]
                loo.append({"comparison": f"{a} - {b}", "metric": metric, "left_out_conversation": conv,
                            "mean_delta": kept.delta.mean()})
        for metric in ["rF1", "rEM"]:
            da, db = aa.loc[ids, metric].to_numpy(float), bb.loc[ids, metric].to_numpy(float)
            wtl.append({"comparison": f"{a} - {b}", "metric": metric,
                        "better": int((da > db + 1e-12).sum()), "tie": int((abs(da-db) <= 1e-12).sum()),
                        "worse": int((da < db - 1e-12).sum())})
    pd.DataFrame(qboot).to_csv(out / "03_query_bootstrap.csv", index=False)
    pd.DataFrame(cboot).to_csv(out / "03_cluster_bootstrap.csv", index=False)
    pd.DataFrame(perconv).to_csv(out / "03_per_conversation_delta.csv", index=False)
    pd.DataFrame(loo).to_csv(out / "03_leave_one_conversation_out.csv", index=False)
    pd.DataFrame(wtl).to_csv(out / "03_win_tie_loss.csv", index=False)

    candidate = cfg.get("decision", {}).get("candidate_method", "ZScore_Linear")
    baseline = cfg.get("decision", {}).get("baseline_method", "Weighted_RRF_dev")
    oi = overall.set_index("Method")
    dmrr, df1, dem, dwa = [float(oi.loc[candidate, x] - oi.loc[baseline, x]) for x in ["MRR", "rF1", "rEM", "WrongAbst"]]
    upgrade = dmrr > 0 and df1 >= 0 and dem >= 0 and dwa <= 0
    decision = f"""# Final Fusion Decision

- **Default fusion:** {candidate if upgrade else baseline}
- **Candidate:** {candidate}
- **Baseline:** {baseline}
- **Retrieval ΔMRR:** {dmrr:+.4f}
- **Reader ΔrF1:** {df1:+.4f}
- **Reader ΔrEM:** {dem:+.4f}
- **Reader ΔWrongAbst:** {dwa:+.4f} (negative is better)
- **Decision:** {'Upgrade to normalized Z-score fusion.' if upgrade else 'Keep the current baseline fusion.'}

A confidence interval crossing zero must be described as maintained or slightly improved reader performance, not a significant reader gain.
"""
    (out / "04_final_fusion_decision.md").write_text(decision, encoding="utf-8")
    json.dump({"expected_tasks": len(tasks), "actual_api_calls": counts["api_calls"], "cache_hits": counts["cache_hits"],
               "failures": counts["failures"], "retries": counts["retries"], "runtime_seconds": time.time()-start,
               "prompt_sha256": prompt_hash, "evaluator_sha256": evaluator_hash},
              (out / "api_run_summary.json").open("w"), indent=2)
    print(overall.to_string(index=False))
    print(f"Done: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
