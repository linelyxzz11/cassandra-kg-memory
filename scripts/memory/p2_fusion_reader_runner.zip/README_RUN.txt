P2 Fusion Reader Runner
=======================

1. Install:
   pip install pandas numpy requests

2. Copy/edit config:
   cp p2_fusion_config.example.json p2_fusion_config.json

3. Point evaluation.adapter_module to the exact historical evaluator adapter.
   Point reader.prompt_file to the exact historical reader prompt.

4. Set API variables:
   export LLM_BASE_URL='https://YOUR-ENDPOINT/v1'
   export LLM_API_KEY='...'
   export LLM_MODEL='YOUR-MODEL'

5. Validate before spending API tokens:
   python run_p2_fusion_reader.py --config p2_fusion_config.json --validate-only

6. Run/resume:
   python run_p2_fusion_reader.py --config p2_fusion_config.json

7. Rebuild reports from cache without API calls:
   python run_p2_fusion_reader.py --config p2_fusion_config.json --offline

Required query columns:
query_id, question, answer, category, conversation_id, gold_memory_ids

Required memory columns:
memory_id, memory_text

Required ranking columns:
query_id, memory_id, rank (or score)

Main outputs:
01_reader_overall.csv
02_reader_by_category.csv
03_query_bootstrap.csv
03_cluster_bootstrap.csv
03_per_conversation_delta.csv
03_leave_one_conversation_out.csv
03_win_tie_loss.csv
04_final_fusion_decision.md
alignment_checks.json
api_run_summary.json
