# Replace these three functions with direct calls to your exact historical evaluator.
import re
from collections import Counter


def _norm(x):
    x = re.sub(r"[^\w\s]", " ", str(x).lower())
    return re.sub(r"\s+", " ", x).strip()


def score_f1(prediction, gold_answer, category=None):
    p, g = _norm(prediction).split(), _norm(gold_answer).split()
    if not p and not g: return 1.0
    if not p or not g: return 0.0
    n = sum((Counter(p) & Counter(g)).values())
    if n == 0: return 0.0
    precision, recall = n / len(p), n / len(g)
    return 2 * precision * recall / (precision + recall)


def score_em(prediction, gold_answer, category=None):
    return float(_norm(prediction) == _norm(gold_answer))


def is_abstain(prediction, category=None):
    x = _norm(prediction)
    return any(k in x for k in ["no information available", "not mentioned", "insufficient information", "cannot be determined"])
